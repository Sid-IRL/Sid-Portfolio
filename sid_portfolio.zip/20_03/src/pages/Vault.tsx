import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { FolderLock, X, ArrowLeft, ExternalLink, Award, FileText } from 'lucide-react';
import AnimatedBackground from '@/components/AnimatedBackground';

interface Certificate {
  id: string;
  title: string;
  issuer: string;
  type: 'certificate' | 'award';
  file?: string;
  image?: string;
}

const certificates: Certificate[] = [
  {
    id: 'high-achiever',
    title: 'High Achiever Award 2025',
    issuer: 'LG Soft India',
    type: 'award',
    file: '/certificates/high-achiever.pdf',
  },
  {
    id: 'linux-privesc',
    title: 'Advanced Linux Privilege Escalation',
    issuer: 'Udemy / Hack The Box',
    type: 'certificate',
    file: '/certificates/linux-privilege-escalation.pdf',
  },
  {
    id: 'aws',
    title: 'AWS Cloud Practitioner',
    issuer: 'Amazon Web Services',
    type: 'certificate',
    file: '/certificates/aws-certificate.pdf',
  },
  {
    id: 'ibm-ai',
    title: 'IBM AI Foundations',
    issuer: 'Coursera / IBM',
    type: 'certificate',
    file: '/certificates/coursera-ibm-ai.pdf',
  },
  {
    id: 'python',
    title: 'Python for Everybody',
    issuer: 'Coursera',
    type: 'certificate',
    file: '/certificates/coursera-python.pdf',
  },
  {
    id: 'cybersecurity-cisco',
    title: 'Cybersecurity Essentials',
    issuer: 'Cisco / NASSCOM',
    type: 'certificate',
    file: '/certificates/cybersecurity-cisco.pdf',
  },
  {
    id: 'cybersecurity-mobility',
    title: 'Cybersecurity & Mobility',
    issuer: 'Coursera',
    type: 'certificate',
    file: '/certificates/cybersecurity-mobility.pdf',
  },
  {
    id: 'google-ux',
    title: 'Google UX Design',
    issuer: 'Google / Coursera',
    type: 'certificate',
    file: '/certificates/google-ux-design.pdf',
  },
  {
    id: 'alfa-zyrus',
    title: 'Automotive Cybersecurity',
    issuer: 'Alfa Zyrus',
    type: 'certificate',
    file: '/certificates/alfa-zyrus.pdf',
  },
  {
    id: 'web-dev',
    title: 'Web Development Training',
    issuer: 'Internshala',
    type: 'certificate',
    image: '/certificates/web-development.jpg',
  },
];

const Vault = () => {
  const navigate = useNavigate();
  const [openFolder, setOpenFolder] = useState<string | null>(null);
  const [vaultUnlocked, setVaultUnlocked] = useState(false);

  // Auto-unlock vault after animation
  useState(() => {
    const timer = setTimeout(() => setVaultUnlocked(true), 1500);
    return () => clearTimeout(timer);
  });

  return (
    <div className="relative min-h-screen bg-background">
      <AnimatedBackground />

      <div className="relative z-10">
        {/* Header */}
        <motion.div
          className="fixed top-0 left-0 right-0 z-40 py-4 px-6 bg-background/80 backdrop-blur-sm border-b border-border/50"
          initial={{ y: -100 }}
          animate={{ y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            <motion.button
              onClick={() => navigate('/')}
              className="script-btn px-4 py-2 rounded-lg terminal-font text-sm flex items-center gap-2"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <ArrowLeft className="w-4 h-4" />
              cd ~/home
            </motion.button>
            <div className="terminal-font text-sm text-primary text-glow">
              VAULT://ACHIEVEMENTS
            </div>
          </div>
        </motion.div>

        {/* Vault Unlock Animation */}
        <AnimatePresence>
          {!vaultUnlocked && (
            <motion.div
              className="fixed inset-0 z-50 bg-background flex items-center justify-center"
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8 }}
            >
              <motion.div
                className="text-center"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
              >
                <motion.div
                  animate={{ rotate: [0, -10, 10, -5, 5, 0] }}
                  transition={{ duration: 0.8, delay: 0.3 }}
                >
                  <FolderLock className="w-24 h-24 text-primary mx-auto mb-4" />
                </motion.div>
                <motion.p
                  className="terminal-font text-primary text-glow"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0, 1, 0.5, 1] }}
                  transition={{ duration: 1, delay: 0.5 }}
                >
                  {'>'} Decrypting vault access...
                </motion.p>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Content */}
        {vaultUnlocked && (
          <div className="pt-24 pb-16 px-4">
            <div className="max-w-6xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="mb-12"
              >
                <span className="terminal-font text-sm text-primary/60">
                  {'>'} ls /vault/achievements/ --classified
                </span>
                <h1 className="text-4xl md:text-6xl font-bold mt-2">
                  The <span className="text-primary text-glow">Vault</span>
                </h1>
                <p className="text-muted-foreground mt-3 max-w-xl">
                  Classified achievements, certifications, and proof of expertise. 
                  Click a folder to decrypt its contents.
                </p>
              </motion.div>

              {/* Certificate Grid */}
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {certificates.map((cert, index) => (
                  <motion.div
                    key={cert.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.1 + index * 0.05 }}
                  >
                    <FolderCard
                      cert={cert}
                      isOpen={openFolder === cert.id}
                      onToggle={() => setOpenFolder(openFolder === cert.id ? null : cert.id)}
                    />
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const FolderCard = ({ 
  cert, 
  isOpen, 
  onToggle 
}: { 
  cert: Certificate; 
  isOpen: boolean; 
  onToggle: () => void;
}) => {
  return (
    <div className="relative">
      {/* Folder Tab */}
      <motion.div
        onClick={onToggle}
        className={`
          relative cursor-pointer rounded-lg overflow-hidden
          ${isOpen ? 'ring-2 ring-primary shadow-glow-strong' : 'cyber-border card-glow'}
          bg-card transition-colors
        `}
        layout
      >
        {/* Folder top flap */}
        <div className="relative">
          <div className="flex items-center gap-3 p-4 pb-3">
            <div className={`p-2 rounded-lg ${cert.type === 'award' ? 'bg-yellow-500/10 border border-yellow-500/30' : 'bg-primary/10 border border-primary/20'}`}>
              {cert.type === 'award' ? (
                <Award className="w-6 h-6 text-yellow-500" />
              ) : (
                <FileText className="w-6 h-6 text-primary" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-sm truncate">{cert.title}</h3>
              <p className="text-xs text-muted-foreground truncate">{cert.issuer}</p>
            </div>
          </div>

          {/* Classification bar */}
          <div className="px-4 pb-3">
            <div className="terminal-font text-[10px] text-primary/50">
              {isOpen ? '> DECRYPTED ✓' : '> ENCRYPTED — click to decrypt'}
            </div>
          </div>
        </div>

        {/* Vault door opening animation */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ 
                duration: 0.5, 
                ease: [0.4, 0, 0.2, 1],
              }}
              className="overflow-hidden border-t border-primary/20"
            >
              {/* Metallic reveal line */}
              <motion.div
                className="h-px bg-gradient-to-r from-transparent via-primary to-transparent"
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 0.6, delay: 0.1 }}
              />

              <div className="p-4 bg-secondary/20">
                {cert.image ? (
                  <div className="rounded-lg overflow-hidden border border-primary/20 mb-3">
                    <img 
                      src={cert.image} 
                      alt={cert.title}
                      className="w-full h-auto"
                      loading="lazy"
                    />
                  </div>
                ) : (
                  <div className="flex items-center justify-center p-8 rounded-lg border border-dashed border-primary/20 bg-primary/5 mb-3">
                    <FileText className="w-12 h-12 text-primary/30" />
                  </div>
                )}

                {cert.file && (
                  <motion.a
                    href={cert.file}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="script-btn w-full px-4 py-2 rounded-lg terminal-font text-xs flex items-center justify-center gap-2"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <ExternalLink className="w-3 h-3" />
                    view_certificate.pdf
                  </motion.a>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

export default Vault;
