import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Download } from 'lucide-react';

const ResumeSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const experience = [
    {
      period: 'Feb 2025 - Present',
      role: 'G1-1 Research Engineer (Security Scrum)',
      company: 'LG Soft India Ltd',
      description: 'Implementing MAC policies with SMACK & AppArmor. Designing Multi-Level Security frameworks. Working with kernel modules for embedded system security. Building custom Yocto binaries with BitBake.',
    },
    {
      period: 'May 2023 - Feb 2025',
      role: 'G1 Research Engineer (Security Scrum)',
      company: 'LG Soft India Ltd',
      description: 'Enforced DAC, MAC, and app sandboxing on webOS. Performed TARA for attack vector identification. Managed Linux containers (LXC/LXD). Contributed to open-source webOS security.',
    },
  ];

  const skills = [
    { name: 'Linux Kernel / Security Modules', level: 95 },
    { name: 'Mandatory Access Control (SMACK/AppArmor)', level: 92 },
    { name: 'Yocto Project / BitBake', level: 88 },
    { name: 'C / C++', level: 85 },
    { name: 'Threat Modeling / TARA', level: 90 },
    { name: 'Linux Containers (LXC/LXD)', level: 82 },
  ];

  return (
    <section id="resume" className="min-h-screen py-20 px-4 relative" ref={ref}>
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-12 flex items-start justify-between flex-wrap gap-4"
        >
          <div>
            <span className="font-mono text-sm text-primary/60">
              {'>'} parse resume.output --format=visual
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mt-2">
              Career <span className="text-primary text-glow">Data</span>
            </h2>
          </div>
          
          <motion.button
            className="script-btn px-5 py-2.5 rounded-lg font-mono text-sm flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ delay: 0.4 }}
          >
            <Download className="w-4 h-4" />
            download.pdf
          </motion.button>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Timeline */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="font-mono text-xs text-muted-foreground mb-4">
              {'>'} timeline.render()
            </div>
            
            <div className="space-y-6">
              {experience.map((exp, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 + index * 0.15 }}
                  className="relative pl-6 border-l-2 border-primary/30"
                >
                  <div className="absolute left-0 top-0 w-3 h-3 bg-primary rounded-full -translate-x-[7px] shadow-glow" />
                  
                  <div className="bg-card cyber-border rounded-lg p-4 card-glow">
                    <div className="font-mono text-xs text-primary mb-1">{exp.period}</div>
                    <h3 className="text-lg font-semibold">{exp.role}</h3>
                    <div className="text-sm text-muted-foreground mb-2">{exp.company}</div>
                    <p className="text-sm text-muted-foreground/80">{exp.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Skills */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <div className="font-mono text-xs text-muted-foreground mb-4">
              {'>'} skills.analyze()
            </div>
            
            <div className="bg-card cyber-border rounded-lg p-6 space-y-5">
              {skills.map((skill, index) => (
                <motion.div
                  key={skill.name}
                  initial={{ opacity: 0 }}
                  animate={isInView ? { opacity: 1 } : {}}
                  transition={{ duration: 0.4, delay: 0.4 + index * 0.1 }}
                >
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">{skill.name}</span>
                    <span className="font-mono text-xs text-primary">{skill.level}%</span>
                  </div>
                  <div className="skill-bar h-2">
                    <motion.div
                      className="skill-bar-fill h-full"
                      initial={{ width: 0 }}
                      animate={isInView ? { width: `${skill.level}%` } : {}}
                      transition={{ duration: 1, delay: 0.5 + index * 0.1, ease: 'easeOut' }}
                    />
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Education */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="mt-6 bg-card cyber-border rounded-lg p-4"
            >
              <div className="font-mono text-xs text-muted-foreground mb-3">
                {'>'} education.show()
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-primary rounded-full mt-2 shrink-0" />
                <div>
                  <h4 className="font-semibold">B.Tech in Information Science & Technology</h4>
                  <p className="text-sm text-muted-foreground">Presidency University • 2019-2023</p>
                </div>
              </div>
            </motion.div>

            {/* Recognition */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.9 }}
              className="mt-4 bg-card cyber-border rounded-lg p-4"
            >
              <div className="font-mono text-xs text-muted-foreground mb-3">
                {'>'} achievements.list()
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-primary rounded-full mt-2 shrink-0" />
                <div>
                  <h4 className="font-semibold text-primary">🏆 LG Soft India High Achiever Award 2025</h4>
                  <p className="text-sm text-muted-foreground">Project Category - Technology Expertise</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ResumeSection;
